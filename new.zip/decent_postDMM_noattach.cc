#include "ap_utils.h"
#include <ap_int.h>
#include <cstdio>
#include <iostream>
static int END = 10000;
static int Pre_Addr = 0;
static int Curr_Addr = 0;
static int malloc_num = 0;
static int free_num = 0;

typedef struct
{
	int size;
	int addr;
	int free_target;
	char cmd;
} dmm_alloc_port;

volatile void LIN_theta(volatile dmm_alloc_port *alloc)
{
io_section0:
{
#pragma HLS protocol fixed
	ap_wait();
	volatile int size = 0, cmd = 0, free_target = 0;
io_section1:
{
#pragma HLS protocol fixed
	cmd = alloc->cmd;
	size = alloc->size;
	free_target = alloc->free_target;
}
	if (cmd == 2)
	{
	io_section2:
	{
#pragma HLS protocol fixed
		malloc_num = malloc_num + 1;
		if (size == 0)
		{
			size = 1;
		}
		if (size >= END - Curr_Addr)
		{
			alloc->addr = -1;
		}
		Pre_Addr = Curr_Addr;
		Curr_Addr = Curr_Addr + size;
	}
	}
	if (cmd == 3)
	{
	io_section4:
	{
#pragma HLS protocol fixed
		free_num = free_num + 1;
		if (malloc_num == free_num)
		{
			Curr_Addr = 0;
			Pre_Addr = 0;
		}
	}
	}
}
	return;
}

template <int limit> volatile int HLS_malloc(int size, volatile dmm_alloc_port *allocator)
{
#pragma HLS INLINE
	int status;
io_section_HLS_malloc:
{
#pragma HLS PROTOCOL fixed
	allocator->cmd = 2; // send cmd and size to allocator
#pragma HLS PROTOCOL fixed
	allocator->size = size;
	allocator->free_target = 0;
	LIN_theta(allocator);
	status = allocator->addr;
	if (status >= limit)
		return -1;
	else
		return status;
}
}

template <int unused> volatile int HLS_free(int free_target, int free_size, volatile dmm_alloc_port *allocator)
{
#pragma HLS INLINE
	int status;
io_section_HLS_free:
{
#pragma HLS PROTOCOL fixed
	allocator->cmd = 3; // send cmd and size to allocator
#pragma HLS PROTOCOL fixed
	allocator->size = free_size;
	allocator->free_target = free_target;
	LIN_theta(allocator);
	return 1;
}
}

int DMM_dynamic_heap_0[16384]; //['tmp']---MAU_size=1---Allocator Management Capability Required: 16384

// DMM replace: void VectorAdd(int a[3], int b[3], int c)
void VectorAdd(int a[3], int b[3], int c, dmm_alloc_port *DMM_allocator_0_LIN2048)
{
#pragma HLS interface ap_hs port = DMM_allocator_0_LIN2048
	int i;
	ap_uint<18> offset_tmp; // DMM insert: offset of pointer tmp
	ap_uint<18> size_tmp;   // DMM insert: size of pointer tmp
	int *tmp;
	size_tmp = 1; // DMM insert: set size of pointer
	// DMM replace:	 tmp = (int *)malloc(sizeof(int));
	offset_tmp = HLS_malloc<16384>(1, DMM_allocator_0_LIN2048);
	tmp = DMM_dynamic_heap_0 + offset_tmp; // DMM insert: stress offset of pointer tmp
	tmp = DMM_dynamic_heap_0 + offset_tmp; // DMM insert: stress offset of pointer tmp
	*tmp = c;
myloop:
	for (int i = 0; i < 3; i++)
	{
		b[i] = a[i] + tmp;
	}
}
