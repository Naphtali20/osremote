#include <cstdio>
#include <cstring>
#include <iostream>
static int END = 10000;
static int Pre_Addr = 0;
static int Curr_Addr = 0;
static int malloc_num = 0;
static int free_num = 0;

typedef struct
{
	int size;
	int addr;
	int free_target;
	char cmd;
} dmm_alloc_port;

volatile void LIN_theta(volatile dmm_alloc_port *alloc)
{
io_section0:
{
#pragma HLS protocol fixed
	volatile int size = 0, cmd = 0, free_target = 0;
io_section1:
{
#pragma HLS protocol fixed
	cmd = alloc->cmd;
	size = alloc->size;
	free_target = alloc->free_target;
}
	if (cmd == 2)
	{
	io_section2:
	{
#pragma HLS protocol fixed
		malloc_num = malloc_num + 1;
		if (size == 0)
		{
			size = 1;
		}
		if (size >= END - Curr_Addr)
		{
			alloc->addr = -1;
		}
		Pre_Addr = Curr_Addr;
		Curr_Addr = Curr_Addr + size;
	}
	}
	if (cmd == 3)
	{
	io_section4:
	{
#pragma HLS protocol fixed
		free_num = free_num + 1;
		if (malloc_num == free_num)
		{
			Curr_Addr = 0;
			Pre_Addr = 0;
		}
	}
	}
}
	return;
}

template <int limit> volatile int HLS_malloc(int size, volatile dmm_alloc_port *allocator)
{
#pragma HLS INLINE
	int status;
io_section_HLS_malloc:
{
#pragma HLS PROTOCOL fixed
	allocator->cmd = 2; // send cmd and size to allocator
#pragma HLS PROTOCOL fixed
	allocator->size = size;
	allocator->free_target = 0;
	LIN_theta(allocator);
	status = allocator->addr;
	if (status >= limit)
		return -1;
	else
		return status;
}
}

template <int unused> volatile int HLS_free(int free_target, int free_size, volatile dmm_alloc_port *allocator)
{
#pragma HLS INLINE
	int status;
io_section_HLS_free:
{
#pragma HLS PROTOCOL fixed
	allocator->cmd = 3; // send cmd and size to allocator
#pragma HLS PROTOCOL fixed
	allocator->size = free_size;
	allocator->free_target = free_target;
	LIN_theta(allocator);
	return 1;
}
}

int DMM_dynamic_heap_0[16384]; //['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'a8']---MAU_size=1---Allocator Management Capability Required: 16384

// DMM replace: void square_constant_size()
void square_constant_size(, dmm_alloc_port *DMM_allocator_0_LIN2048)
{
	ap_uint<18> offset_a1; // DMM insert: offset of pointer a1
	ap_uint<18> size_a1;   // DMM insert: size of pointer a1
#pragma HLS interface ap_hs port = DMM_allocator_0_LIN2048
	int *a1;
	size_a1 = 1; // DMM insert: set size of pointer
	// DMM replace:	 a1 = (int *)malloc(sizeof(int));
	offset_a1 = HLS_malloc<16384>(1, DMM_allocator_0_LIN2048);
	a1 = DMM_dynamic_heap_0 + offset_a1; // DMM insert: stress offset of pointer a1
	// DMM replace:	 free(a1);
	HLS_free<0>(offset_a1, size_a1, DMM_allocator_0_LIN2048);
	ap_uint<18> offset_a2; // DMM insert: offset of pointer a2
	ap_uint<18> size_a2;   // DMM insert: size of pointer a2
	int *a2;
	size_a2 = 1; // DMM insert: set size of pointer
	// DMM replace:	 a2 = (int *)malloc(sizeof(int));
	offset_a2 = HLS_malloc<16384>(1, DMM_allocator_0_LIN2048);
	a2 = DMM_dynamic_heap_0 + offset_a2; // DMM insert: stress offset of pointer a2
	// DMM replace:	 free(a2);
	HLS_free<1>(offset_a2, size_a2, DMM_allocator_0_LIN2048);
	ap_uint<18> offset_a3; // DMM insert: offset of pointer a3
	ap_uint<18> size_a3;   // DMM insert: size of pointer a3
	int *a3;
	size_a3 = 1; // DMM insert: set size of pointer
	// DMM replace:	 a3 = (int *)malloc(sizeof(int));
	offset_a3 = HLS_malloc<16384>(1, DMM_allocator_0_LIN2048);
	a3 = DMM_dynamic_heap_0 + offset_a3; // DMM insert: stress offset of pointer a3
	// DMM replace:	 free(a3);
	HLS_free<2>(offset_a3, size_a3, DMM_allocator_0_LIN2048);
	ap_uint<18> offset_a4; // DMM insert: offset of pointer a4
	ap_uint<18> size_a4;   // DMM insert: size of pointer a4
	int *a4;
	size_a4 = 1; // DMM insert: set size of pointer
	// DMM replace:	 a4 = (int *)malloc(sizeof(int));
	offset_a4 = HLS_malloc<16384>(1, DMM_allocator_0_LIN2048);
	a4 = DMM_dynamic_heap_0 + offset_a4; // DMM insert: stress offset of pointer a4
	// DMM replace:	 free(a4);
	HLS_free<3>(offset_a4, size_a4, DMM_allocator_0_LIN2048);
	ap_uint<18> offset_a5; // DMM insert: offset of pointer a5
	ap_uint<18> size_a5;   // DMM insert: size of pointer a5
	int *a5;
	size_a5 = 1; // DMM insert: set size of pointer
	// DMM replace:	 a5 = (int *)malloc(sizeof(int));
	offset_a5 = HLS_malloc<16384>(1, DMM_allocator_0_LIN2048);
	a5 = DMM_dynamic_heap_0 + offset_a5; // DMM insert: stress offset of pointer a5
	// DMM replace:	 free(a5);
	HLS_free<4>(offset_a5, size_a5, DMM_allocator_0_LIN2048);
	ap_uint<18> offset_a6; // DMM insert: offset of pointer a6
	ap_uint<18> size_a6;   // DMM insert: size of pointer a6
	int *a6;
	size_a6 = 1; // DMM insert: set size of pointer
	// DMM replace:	 a6 = (int *)malloc(sizeof(int));
	offset_a6 = HLS_malloc<16384>(1, DMM_allocator_0_LIN2048);
	a6 = DMM_dynamic_heap_0 + offset_a6; // DMM insert: stress offset of pointer a6
	// DMM replace:	 free(a6);
	HLS_free<5>(offset_a6, size_a6, DMM_allocator_0_LIN2048);
	ap_uint<18> offset_a7; // DMM insert: offset of pointer a7
	ap_uint<18> size_a7;   // DMM insert: size of pointer a7
	int *a7;
	size_a7 = 1; // DMM insert: set size of pointer
	// DMM replace:	 a7 = (int *)malloc(sizeof(int));
	offset_a7 = HLS_malloc<16384>(1, DMM_allocator_0_LIN2048);
	a7 = DMM_dynamic_heap_0 + offset_a7; // DMM insert: stress offset of pointer a7
	// DMM replace:	 free(a7);
	HLS_free<6>(offset_a7, size_a7, DMM_allocator_0_LIN2048);
	ap_uint<18> offset_a8; // DMM insert: offset of pointer a8
	ap_uint<18> size_a8;   // DMM insert: size of pointer a8
	int *a8;
	size_a8 = 1; // DMM insert: set size of pointer
	// DMM replace:	 a8 = (int *)malloc(sizeof(int));
	offset_a8 = HLS_malloc<16384>(1, DMM_allocator_0_LIN2048);
	a8 = DMM_dynamic_heap_0 + offset_a8; // DMM insert: stress offset of pointer a8
	// DMM replace:	 free(a8);
	HLS_free<7>(offset_a8, size_a8, DMM_allocator_0_LIN2048);
}
